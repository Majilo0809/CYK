grammar Expresion;

expr : expr '+' term
     | term
     ;

term : term '*' factor
     | factor
     ;

factor : '(' expr ')'
       | ID
       ;

ID : [a-zA-Z]+;
WS : [ \t\r\n]+ -> skip;
