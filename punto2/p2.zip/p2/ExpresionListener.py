# Generated from Expresion.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .ExpresionParser import ExpresionParser
else:
    from ExpresionParser import ExpresionParser

# This class defines a complete listener for a parse tree produced by ExpresionParser.
class ExpresionListener(ParseTreeListener):

    # Enter a parse tree produced by ExpresionParser#expr.
    def enterExpr(self, ctx:ExpresionParser.ExprContext):
        pass

    # Exit a parse tree produced by ExpresionParser#expr.
    def exitExpr(self, ctx:ExpresionParser.ExprContext):
        pass


    # Enter a parse tree produced by ExpresionParser#term.
    def enterTerm(self, ctx:ExpresionParser.TermContext):
        pass

    # Exit a parse tree produced by ExpresionParser#term.
    def exitTerm(self, ctx:ExpresionParser.TermContext):
        pass


    # Enter a parse tree produced by ExpresionParser#factor.
    def enterFactor(self, ctx:ExpresionParser.FactorContext):
        pass

    # Exit a parse tree produced by ExpresionParser#factor.
    def exitFactor(self, ctx:ExpresionParser.FactorContext):
        pass



del ExpresionParser