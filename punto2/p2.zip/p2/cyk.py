import random
import time
import tracemalloc

grammar = {
    ("E", "PLUS_T"): "E",
    ("T",): "E",

    ("PLUS", "T"): "PLUS_T",

    ("T", "TIMES_F"): "T",
    ("F",): "T",

    ("TIMES", "F"): "TIMES_F",

    ("LPAREN", "E_RPAREN"): "F",
    ("ID",): "F",

    ("E", "RPAREN"): "E_RPAREN"
}

terminal_rules = {
    "id": "ID",
    "+": "PLUS",
    "*": "TIMES",
    "(": "LPAREN",
    ")": "RPAREN"
}

def generar_tokens(n):
    simbolos = ["id", "+", "*", "(", ")"]
    return [random.choice(simbolos) for _ in range(n)]

# ALGORITMO CYK

def cyk(tokens):

    n = len(tokens)
    table = [[set() for _ in range(n)] for _ in range(n)]

    for i in range(n):
        table[i][i].add(terminal_rules[tokens[i]])

    for length in range(2, n + 1):
        for i in range(n - length + 1):
            j = i + length - 1

            for k in range(i, j):
                for a in table[i][k]:
                    for b in table[k + 1][j]:

                        if (a, b) in grammar:
                            table[i][j].add(grammar[(a, b)])

    return "E" in table[0][n - 1]

def medir_cyk(n):

    tokens = generar_tokens(n)

    tracemalloc.start()
    inicio = time.time()

    cyk(tokens)

    fin = time.time()
    memoria = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()

    return fin - inicio, memoria
