from cyk import medir_cyk
import random
import time
import tracemalloc

from antlr4 import *
from ExpresionLexer import ExpresionLexer
from ExpresionParser import ExpresionParser

def generar_texto(n):
    simbolos = ["id", "+", "*", "(", ")"]
    return " ".join(random.choice(simbolos) for _ in range(n))


def medir_antlr(n):

    texto = generar_texto(n)

    tracemalloc.start()
    inicio = time.time()

    input_stream = InputStream(texto)
    lexer = ExpresionLexer(input_stream)
    tokens = CommonTokenStream(lexer)
    parser = ExpresionParser(tokens)

    parser.removeErrorListeners()

    parser.expr()

    fin = time.time()
    memoria = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()

    return fin - inicio, memoria


# COMPARACIÓN

print("\nComparación CYK vs ANTLR\n")
print("n\tCYK tiempo\tANTLR tiempo\tCYK memoria\tANTLR memoria")
print("------------------------------------------------------------")

for n in range(20, 201, 20):

    t1, m1 = medir_cyk(n)
    t2, m2 = medir_antlr(n)

    print(f"{n}\t{t1:.6f}\t{t2:.6f}\t{m1}\t{m2}")
