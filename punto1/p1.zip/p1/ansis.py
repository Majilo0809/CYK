import matplotlib.pyplot as plt


class Nodo:
    def __init__(self, valor):
        self.valor = valor
        self.hijos = []

    def agregar(self, hijo):
        self.hijos.append(hijo)


# Gramatica

# E → E + T | T
# T → T * F | F
# F → num | (E)
class Parser:

    def __init__(self, cadena):
        self.cadena = cadena.replace(" ", "")
        self.pos = 0


    # Leer número
    def numero(self):
        inicio = self.pos

        while self.pos < len(self.cadena) and self.cadena[self.pos].isdigit():
            self.pos += 1

        return self.cadena[inicio:self.pos]


    # F → num | (E)
    def F(self):
        nodo = Nodo("F")

        # número completo
        if self.pos < len(self.cadena) and self.cadena[self.pos].isdigit():
            num = self.numero()
            nodo.agregar(Nodo(num))
            return nodo

        # (E)
        if self.pos < len(self.cadena) and self.cadena[self.pos] == '(':
            nodo.agregar(Nodo("("))
            self.pos += 1

            nodo.agregar(self.E())

            if self.pos < len(self.cadena) and self.cadena[self.pos] == ')':
                nodo.agregar(Nodo(")"))
                self.pos += 1
                return nodo

        return None

    # T → T * F | F
    def T(self):
        nodo = Nodo("T")
        izquierdo = self.F()

        while self.pos < len(self.cadena) and self.cadena[self.pos] in "*/":
            op = Nodo(self.cadena[self.pos])
            self.pos += 1

            nuevo = Nodo("T")
            nuevo.agregar(izquierdo)
            nuevo.agregar(op)
            nuevo.agregar(self.F())
            izquierdo = nuevo

        nodo.agregar(izquierdo)
        return nodo


    # E → E + T | T
    def E(self):
        nodo = Nodo("E")
        izquierdo = self.T()

        while self.pos < len(self.cadena) and self.cadena[self.pos] in "+-":
            op = Nodo(self.cadena[self.pos])
            self.pos += 1

            nuevo = Nodo("E")
            nuevo.agregar(izquierdo)
            nuevo.agregar(op)
            nuevo.agregar(self.T())
            izquierdo = nuevo

        nodo.agregar(izquierdo)
        return nodo


def obtener_posiciones(nodo, x=0, y=0, dx=2):
    posiciones = {nodo: (x, y)}

    if nodo.hijos:
        ancho = dx * (len(nodo.hijos) - 1)
        inicio = x - ancho/2

        for i, h in enumerate(nodo.hijos):
            posiciones.update(
                obtener_posiciones(h, inicio + i*dx, y-1, dx/1.8)
            )

    return posiciones


def dibujar_arbol(raiz, texto):

    pos = obtener_posiciones(raiz)

    plt.figure(figsize=(10, 6))

    for nodo, (x, y) in pos.items():
        plt.text(x, y, nodo.valor, ha='center', fontsize=12)

        for h in nodo.hijos:
            x2, y2 = pos[h]
            plt.plot([x, x2], [y, y2])

    plt.axis('off')
    plt.title("Árbol sintáctico: " + texto)
    plt.show()


archivo = "entrada1.txt"

with open(archivo, "r") as f:
    lineas = f.readlines()


# Procesar cada cadena
for linea in lineas:
    cadena = linea.strip()

    if cadena == "":
        continue

    print("\nProcesando:", cadena)

    parser = Parser(cadena)
    arbol = parser.E()

    dibujar_arbol(arbol, cadena)
