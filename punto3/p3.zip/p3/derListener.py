# Generated from der.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .derParser import derParser
else:
    from derParser import derParser

# This class defines a complete listener for a parse tree produced by derParser.
class derListener(ParseTreeListener):

    # Enter a parse tree produced by derParser#expr.
    def enterExpr(self, ctx:derParser.ExprContext):
        pass

    # Exit a parse tree produced by derParser#expr.
    def exitExpr(self, ctx:derParser.ExprContext):
        pass



del derParser