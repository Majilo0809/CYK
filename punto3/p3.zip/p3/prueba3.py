from antlr4 import *

from izqLexer import izqLexer
from izqParser import izqParser

from derLexer import derLexer
from derParser import derParser

from prenormalLexer import prenormalLexer
from prenormalParser import prenormalParser

from preinvLexer import preinvLexer
from preinvParser import preinvParser


# =====================================================
# EVALUADOR UNIVERSAL DEL ÁRBOL SINTÁCTICO
# =====================================================

def evaluar(tree):

    # si es un número
    if tree.getChildCount() == 0:
        return int(tree.getText())

    # si tiene un solo hijo → bajar
    if tree.getChildCount() == 1:
        return evaluar(tree.getChild(0))

    # buscar operador en los hijos
    for i in range(tree.getChildCount()):
        texto = tree.getChild(i).getText()

        if texto in ['+', '-', '*']:
            izquierda = evaluar(tree.getChild(i-1))
            derecha   = evaluar(tree.getChild(i+1))

            if texto == '+':
                return izquierda + derecha
            if texto == '-':
                return izquierda - derecha
            if texto == '*':
                return izquierda * derecha

    # si no encontró operador, bajar
    return evaluar(tree.getChild(0))


# =====================================================
# FUNCIÓN PARA PROBAR UNA CADENA
# =====================================================

def probar(texto, Lexer, Parser):

    input_stream = InputStream(texto)
    lexer = Lexer(input_stream)
    tokens = CommonTokenStream(lexer)
    parser = Parser(tokens)

    parser.removeErrorListeners()

    tree = parser.expr()

    return evaluar(tree)


# =====================================================
# LEER ARCHIVO entrada3.txt
# =====================================================

with open("entrada3.txt") as f:
    lineas = [l.strip() for l in f if l.strip()]


# =====================================================
# PRUEBA 1 → ASOCIATIVIDAD
# =====================================================

cadena1 = lineas[0]

print("Cadena:", cadena1)

print("Izquierda :", probar(cadena1, izqLexer, izqParser))
print("Derecha   :", probar(cadena1, derLexer, derParser))


# =====================================================
# PRUEBA 2 → PRECEDENCIA
# =====================================================

cadena2 = lineas[1]

print("\nCadena:", cadena2)

print("Normal   :", probar(cadena2, prenormalLexer, prenormalParser))
print("Invertida:", probar(cadena2, preinvLexer, preinvParser))
