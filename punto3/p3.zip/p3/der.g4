grammar der;

expr : INT '-' expr
     | INT
     ;

INT : [0-9]+;
WS : [ \t\r\n]+ -> skip;
