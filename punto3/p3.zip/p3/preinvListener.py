# Generated from preinv.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .preinvParser import preinvParser
else:
    from preinvParser import preinvParser

# This class defines a complete listener for a parse tree produced by preinvParser.
class preinvListener(ParseTreeListener):

    # Enter a parse tree produced by preinvParser#expr.
    def enterExpr(self, ctx:preinvParser.ExprContext):
        pass

    # Exit a parse tree produced by preinvParser#expr.
    def exitExpr(self, ctx:preinvParser.ExprContext):
        pass


    # Enter a parse tree produced by preinvParser#term.
    def enterTerm(self, ctx:preinvParser.TermContext):
        pass

    # Exit a parse tree produced by preinvParser#term.
    def exitTerm(self, ctx:preinvParser.TermContext):
        pass


    # Enter a parse tree produced by preinvParser#factor.
    def enterFactor(self, ctx:preinvParser.FactorContext):
        pass

    # Exit a parse tree produced by preinvParser#factor.
    def exitFactor(self, ctx:preinvParser.FactorContext):
        pass



del preinvParser