grammar preinv;

expr   : expr '*' term
       | term
       ;

term   : term '+' factor
       | term '-' factor
       | factor
       ;

factor : NUM
       | '(' expr ')'
       ;

NUM : [0-9]+;
WS  : [ \t\r\n]+ -> skip;
