# Generated from izq.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .izqParser import izqParser
else:
    from izqParser import izqParser

# This class defines a complete listener for a parse tree produced by izqParser.
class izqListener(ParseTreeListener):

    # Enter a parse tree produced by izqParser#expr.
    def enterExpr(self, ctx:izqParser.ExprContext):
        pass

    # Exit a parse tree produced by izqParser#expr.
    def exitExpr(self, ctx:izqParser.ExprContext):
        pass



del izqParser