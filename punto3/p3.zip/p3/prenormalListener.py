# Generated from prenormal.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .prenormalParser import prenormalParser
else:
    from prenormalParser import prenormalParser

# This class defines a complete listener for a parse tree produced by prenormalParser.
class prenormalListener(ParseTreeListener):

    # Enter a parse tree produced by prenormalParser#expr.
    def enterExpr(self, ctx:prenormalParser.ExprContext):
        pass

    # Exit a parse tree produced by prenormalParser#expr.
    def exitExpr(self, ctx:prenormalParser.ExprContext):
        pass


    # Enter a parse tree produced by prenormalParser#term.
    def enterTerm(self, ctx:prenormalParser.TermContext):
        pass

    # Exit a parse tree produced by prenormalParser#term.
    def exitTerm(self, ctx:prenormalParser.TermContext):
        pass


    # Enter a parse tree produced by prenormalParser#factor.
    def enterFactor(self, ctx:prenormalParser.FactorContext):
        pass

    # Exit a parse tree produced by prenormalParser#factor.
    def exitFactor(self, ctx:prenormalParser.FactorContext):
        pass



del prenormalParser